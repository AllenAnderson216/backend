from fastapi import FastAPI, Depends, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import Base, engine, get_db
from models import Project, Scene, Asset
from pipeline.runner import run_pipeline

Base.metadata.create_all(bind=engine)

app = FastAPI(title="AI短视频一键出片平台")


class CreateProjectRequest(BaseModel):
    topic: str


@app.post("/projects")
def create_project(req: CreateProjectRequest, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    """创建一个新项目，并在后台自动跑完整个流水线（一键出片）"""
    project = Project(topic=req.topic, status="created")
    db.add(project)
    db.commit()
    db.refresh(project)

    # 后台任务需要自己的DB session，不能复用请求级别的session
    from database import SessionLocal

    def _run():
        session = SessionLocal()
        try:
            run_pipeline(project.id, session)
        finally:
            session.close()

    background_tasks.add_task(_run)
    return {"project_id": project.id, "status": project.status}


@app.get("/projects/{project_id}")
def get_project(project_id: int, db: Session = Depends(get_db)):
    """查询项目当前进度，包括每个分镜的生成状态"""
    project = db.query(Project).get(project_id)
    if not project:
        raise HTTPException(404, "项目不存在")

    scenes = db.query(Scene).filter(Scene.project_id == project_id).order_by(Scene.order).all()
    return {
        "id": project.id,
        "topic": project.topic,
        "status": project.status,
        "error_message": project.error_message,
        "script": project.script,
        "output_path": project.output_path,
        "scenes": [
            {
                "order": s.order,
                "description": s.description,
                "dialogue": s.dialogue,
                "image_path": s.image_path,
                "video_path": s.video_path,
                "audio_path": s.audio_path,
            }
            for s in scenes
        ],
    }


@app.get("/projects")
def list_projects(db: Session = Depends(get_db)):
    projects = db.query(Project).order_by(Project.id.desc()).all()
    return [{"id": p.id, "topic": p.topic, "status": p.status} for p in projects]


@app.get("/projects/{project_id}/download")
def download_video(project_id: int, db: Session = Depends(get_db)):
    """下载最终成片"""
    project = db.query(Project).get(project_id)
    if not project or not project.output_path:
        raise HTTPException(404, "成片还没生成好")
    return FileResponse(project.output_path, filename=f"project_{project_id}.mp4")


@app.post("/projects/{project_id}/retry")
def retry_project(project_id: int, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    """某一步失败后（project.error_message非空），修好问题（比如补上API key）再调用这个接口，
    会从上次成功完成的步骤之后继续跑，不用整条流程重来。"""
    project = db.query(Project).get(project_id)
    if not project:
        raise HTTPException(404, "项目不存在")
    project.error_message = ""
    db.commit()

    from database import SessionLocal

    def _run():
        session = SessionLocal()
        try:
            run_pipeline(project_id, session)
        finally:
            session.close()

    background_tasks.add_task(_run)
    return {"project_id": project_id, "status": "retrying"}
