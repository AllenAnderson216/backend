"""
第三阶段：资产清单生成
从分镜描述中提炼出需要保持一致性的角色/场景/道具，
每个资产先单独生成一张"定妆照"，后续所有分镜出图都基于这张参考图，
避免同一角色在不同镜头里长相不一致。
"""
import json
import re
import httpx
import config


def extract_assets(scenes: list[dict]) -> list[dict]:
    scenes_text = "\n".join(f"{i+1}. {s['description']}" for i, s in enumerate(scenes))
    prompt = f"""下面是短视频的分镜画面描述列表。请从中提炼出反复出现、需要保持形象一致的资产（角色/场景/重要道具）。
只输出JSON数组，不要解释文字：
[{{"name": "资产名称，如'女主角-小美'", "asset_type": "character或scene或prop", "reference_prompt": "用于生成该资产定妆照/参考图的详细prompt"}}]

分镜列表：
{scenes_text}
"""
    resp = httpx.post(
        f"{config.QWEN_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {config.QWEN_API_KEY}"},
        json={"model": "qwen-plus", "messages": [{"role": "user", "content": prompt}]},
        timeout=60,
    )
    resp.raise_for_status()
    raw = resp.json()["choices"][0]["message"]["content"].strip()
    raw = re.sub(r"^```json|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    return json.loads(raw)
