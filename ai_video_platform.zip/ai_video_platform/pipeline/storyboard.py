"""
第二阶段：分镜拆解
把剧本拆成一系列分镜，每个分镜包含：画面描述、台词、建议时长。
要求LLM只输出JSON，方便直接解析入库。
"""
import json
import re
import httpx
import config


def break_into_scenes(script: str) -> list[dict]:
    prompt = f"""请把下面的短视频剧本拆解成分镜列表。
只输出JSON数组，不要任何解释文字，不要markdown代码块标记。
每个元素格式：
{{"description": "画面内容描述，用于AI生图/生视频的prompt，尽量具体，包含人物/场景/动作/镜头角度", "dialogue": "这个镜头对应的台词或旁白", "duration_sec": 建议时长秒数(整数)}}

剧本：
{script}
"""
    resp = httpx.post(
        f"{config.QWEN_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {config.QWEN_API_KEY}"},
        json={
            "model": "qwen-plus",
            "messages": [{"role": "user", "content": prompt}],
        },
        timeout=60,
    )
    resp.raise_for_status()
    raw = resp.json()["choices"][0]["message"]["content"].strip()

    # 兜底：去掉可能出现的 ```json 包裹
    raw = re.sub(r"^```json|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    scenes = json.loads(raw)
    return scenes
