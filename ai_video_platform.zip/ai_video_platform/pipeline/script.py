"""
第一阶段：剧本生成
调用通义千问（DashScope，兼容OpenAI接口格式）根据主题生成完整剧本文本。
"""
import httpx
import config


def generate_script(topic: str) -> str:
    prompt = f"""你是一个短视频编剧。请根据下面的主题，写一个适合短视频（60-90秒）的完整剧本。
要求：
1. 有明确的开头、冲突、结尾
2. 语言口语化，适合配音朗读
3. 直接输出剧本正文，不要加解释

主题：{topic}
"""
    resp = httpx.post(
        f"{config.QWEN_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {config.QWEN_API_KEY}"},
        json={
            "model": "qwen-plus",
            "messages": [{"role": "user", "content": prompt}],
        },
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"].strip()
