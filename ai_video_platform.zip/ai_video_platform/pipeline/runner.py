"""
流水线主控：按顺序跑完 剧本->分镜->资产->图片->配音->视频->合成，
每一步更新Project.status，出错则记录error_message并停在失败的那一步
（方便修好问题后手动重跑，而不用整条流程重来）。
"""
from pathlib import Path
from sqlalchemy.orm import Session

import config
from models import Project, Scene, Asset
from pipeline import script as script_stage
from pipeline import storyboard as storyboard_stage
from pipeline import assets as assets_stage
from pipeline import image_gen
from pipeline import video_gen
from pipeline import voiceover
from pipeline import compose


# 各阶段完成后的状态，用于判断重跑时该从哪一步继续
STATUS_ORDER = [
    "created", "script_done", "storyboard_done", "assets_done",
    "images_done", "audio_done", "video_done", "composed",
]


def run_pipeline(project_id: int, db: Session):
    project = db.query(Project).get(project_id)
    current = project.status if project.status in STATUS_ORDER else "created"
    start_index = STATUS_ORDER.index(current)

    steps = [
        _step_script, _step_storyboard, _step_assets,
        _step_images, _step_audio, _step_videos, _step_compose,
    ]
    try:
        # 断点续跑：跳过状态已经达到的步骤，只从失败的那一步继续
        for step in steps[start_index:]:
            step(project, db)
        project.error_message = ""
        db.commit()
    except Exception as e:
        # 注意：这里不覆盖project.status，status停在"最后一步成功完成"的状态，
        # 这样重试时会从失败的那一步重新开始，而不是从头跑一遍。
        # 项目是否处于失败态，看error_message是否非空。
        project.error_message = str(e)
        db.commit()
        raise


def _step_script(project: Project, db: Session):
    project.script = script_stage.generate_script(project.topic)
    project.status = "script_done"
    db.commit()


def _step_storyboard(project: Project, db: Session):
    scenes_data = storyboard_stage.break_into_scenes(project.script)
    for i, s in enumerate(scenes_data):
        db.add(Scene(
            project_id=project.id,
            order=i,
            description=s["description"],
            dialogue=s.get("dialogue", ""),
            duration_sec=s.get("duration_sec", 5),
        ))
    project.status = "storyboard_done"
    db.commit()


def _step_assets(project: Project, db: Session):
    scenes = db.query(Scene).filter(Scene.project_id == project.id).order_by(Scene.order).all()
    scenes_data = [{"description": s.description} for s in scenes]
    assets_data = assets_stage.extract_assets(scenes_data)
    for a in assets_data:
        db.add(Asset(
            project_id=project.id,
            name=a["name"],
            asset_type=a.get("asset_type", "character"),
            reference_prompt=a.get("reference_prompt", ""),
        ))
    project.status = "assets_done"
    db.commit()

    # 为每个资产生成一张定妆照，后续分镜出图会参考它保持一致性
    pdir = config.project_dir(project.id)
    for asset in db.query(Asset).filter(Asset.project_id == project.id).all():
        path = pdir / "images" / f"asset_{asset.id}.png"
        image_gen.generate_image(asset.reference_prompt, path)
        asset.reference_image_path = str(path)
    db.commit()


def _step_images(project: Project, db: Session):
    pdir = config.project_dir(project.id)
    scenes = db.query(Scene).filter(Scene.project_id == project.id).order_by(Scene.order).all()
    for scene in scenes:
        path = pdir / "images" / f"scene_{scene.order}.png"
        # 简化版：不做角色匹配，直接用分镜描述生图；
        # 想做得更好可以在这里检测description里提到了哪个资产名，传对应reference_image_path
        image_gen.generate_image(scene.description, path)
        scene.image_path = str(path)
    project.status = "images_done"
    db.commit()


def _step_audio(project: Project, db: Session):
    pdir = config.project_dir(project.id)
    scenes = db.query(Scene).filter(Scene.project_id == project.id).order_by(Scene.order).all()
    for scene in scenes:
        path = pdir / "audio" / f"scene_{scene.order}.mp3"
        voiceover.generate_voiceover(scene.dialogue, path, duration_sec=scene.duration_sec)
        scene.audio_path = str(path)
    project.status = "audio_done"
    db.commit()


def _step_videos(project: Project, db: Session):
    pdir = config.project_dir(project.id)
    scenes = db.query(Scene).filter(Scene.project_id == project.id).order_by(Scene.order).all()
    use_real_api = bool(config.KLING_ACCESS_KEY and config.KLING_SECRET_KEY)
    for scene in scenes:
        path = pdir / "videos" / f"scene_{scene.order}.mp4"
        if use_real_api:
            video_gen.generate_video(scene.image_path, scene.description, scene.duration_sec, path)
        else:
            # 没配置可灵key时，自动降级为图片+运镜方案，保证流水线能跑通
            video_gen.image_to_video_fallback(scene.image_path, scene.duration_sec, path)
        scene.video_path = str(path)
    project.status = "video_done"
    db.commit()


def _step_compose(project: Project, db: Session):
    pdir = config.project_dir(project.id)
    scenes = db.query(Scene).filter(Scene.project_id == project.id).order_by(Scene.order).all()

    muxed_clips = []
    for scene in scenes:
        muxed_path = pdir / "output" / f"muxed_{scene.order}.mp4"
        compose.mux_video_audio(scene.video_path, scene.audio_path, muxed_path)
        muxed_clips.append(str(muxed_path))

    final_path = pdir / "output" / "final.mp4"
    compose.concat_clips(muxed_clips, final_path)

    project.output_path = str(final_path)
    project.status = "composed"
    db.commit()
