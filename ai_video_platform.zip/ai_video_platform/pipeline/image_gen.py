"""
第四阶段：图片生成

⚠️ 注意：通义万相 / 即梦 的具体API endpoint、参数字段、鉴权方式经常更新，
这里只搭好函数接口和调用位置，实际请求体请对照你申请key时官方最新文档核对再填：
- 通义万相: https://help.aliyun.com/zh/dashscope/  (搜索 "文生图" / "图生图")
- 即梦AI:   https://jimeng.jianying.com/ 开放平台文档

函数约定：
- generate_image(prompt, reference_image_path=None) -> 本地图片文件路径
- reference_image_path 不为空时，走"图生图"模式，用于保持角色/场景一致性
"""
import httpx
import config
from pathlib import Path


def generate_image(prompt: str, save_path: Path, reference_image_path: str | None = None) -> str:
    if not config.IMAGE_API_KEY:
        # 还没配置图片生成API key时，先用占位图跑通整条流水线
        return _generate_placeholder(prompt, save_path)

    if config.IMAGE_PROVIDER == "wanxiang":
        image_bytes = _call_wanxiang(prompt, reference_image_path)
    elif config.IMAGE_PROVIDER == "jimeng":
        image_bytes = _call_jimeng(prompt, reference_image_path)
    else:
        raise ValueError(f"未知的图片生成provider: {config.IMAGE_PROVIDER}")

    save_path.write_bytes(image_bytes)
    return str(save_path)


def _call_wanxiang(prompt: str, reference_image_path: str | None) -> bytes:
    # TODO: 对照通义万相最新文档确认 endpoint 和请求体字段
    # 文生图和图生图（图生图需要先上传参考图或传base64/url）的接口路径不同，
    # 请在拿到API key后查阅一次官方示例代码，替换下面这段。
    resp = httpx.post(
        "https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis",
        headers={"Authorization": f"Bearer {config.IMAGE_API_KEY}"},
        json={"model": "wanx-v1", "input": {"prompt": prompt}},
        timeout=120,
    )
    resp.raise_for_status()
    # 万相是异步任务，实际使用需要轮询任务状态后再下载图片，这里简化示意
    raise NotImplementedError("请对照通义万相异步任务文档补充：提交任务 -> 轮询结果 -> 下载图片字节")


def _call_jimeng(prompt: str, reference_image_path: str | None) -> bytes:
    # TODO: 对照即梦开放平台文档补充
    raise NotImplementedError("请对照即梦AI开放平台文档补充图片生成调用逻辑")


def _generate_placeholder(prompt: str, save_path: Path) -> str:
    """未配置API key时的占位图：把prompt文字画在纯色底图上，方便先验证整条流水线跑通"""
    from PIL import Image, ImageDraw

    img = Image.new("RGB", (1080, 1920), color=(60, 60, 90))
    draw = ImageDraw.Draw(img)
    text = prompt[:200]
    lines = [text[i:i + 30] for i in range(0, len(text), 30)]
    y = 800
    for line in lines:
        draw.text((60, y), line, fill=(255, 255, 255))
        y += 40
    img.save(save_path)
    return str(save_path)
