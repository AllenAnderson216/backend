"""
第六阶段：配音生成
把每个分镜的台词逐句合成语音。阿里云和腾讯云的TTS都有现成SDK，
比手写HTTP请求更省心，建议直接 pip install 对应SDK：
- 阿里云: pip install alibabacloud-nls  (或使用 dashscope 的 CosyVoice 语音合成接口)
- 腾讯云: pip install tencentcloud-sdk-python
"""
import config
from pathlib import Path


def generate_voiceover(text: str, save_path: Path, duration_sec: int = 5) -> str:
    if not config.TTS_API_KEY:
        # 还没配置TTS API key时，先生成对应时长的静音音频，跑通整条流水线
        return _generate_placeholder(save_path, duration_sec)

    if config.TTS_PROVIDER == "aliyun":
        audio_bytes = _call_aliyun_tts(text)
    elif config.TTS_PROVIDER == "tencent":
        audio_bytes = _call_tencent_tts(text)
    else:
        raise ValueError(f"未知的TTS provider: {config.TTS_PROVIDER}")

    save_path.write_bytes(audio_bytes)
    return str(save_path)


def _call_aliyun_tts(text: str) -> bytes:
    # TODO: 用阿里云语音合成SDK或DashScope的CosyVoice接口替换
    # 参考: https://help.aliyun.com/zh/dashscope/developer-reference/cosyvoice-quick-start
    raise NotImplementedError("请接入阿里云TTS/CosyVoice SDK")


def _call_tencent_tts(text: str) -> bytes:
    # TODO: 用腾讯云语音合成SDK替换
    raise NotImplementedError("请接入腾讯云TTS SDK")


def _generate_placeholder(save_path: Path, duration_sec: int) -> str:
    """未配置API key时的占位音频：生成对应时长的静音，方便先验证整条流水线跑通"""
    import subprocess
    cmd = [
        "ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono",
        "-t", str(duration_sec), str(save_path),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return str(save_path)
