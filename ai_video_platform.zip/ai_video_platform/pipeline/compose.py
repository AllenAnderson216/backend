"""
第七阶段：最终合成
用FFmpeg把每个分镜的视频片段（已经过图生视频或Ken Burns降级方案）
分别配上对应的配音，再首尾拼接成一条完整视频。
"""
import subprocess
from pathlib import Path


def mux_video_audio(video_path: str, audio_path: str, out_path: Path) -> str:
    """给单个分镜视频配上对应的配音"""
    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path), "-i", str(audio_path),
        "-c:v", "copy", "-map", "0:v:0", "-map", "1:a:0",
        "-shortest",
        str(out_path),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return str(out_path)


def concat_clips(clip_paths: list[str], final_output_path: Path) -> str:
    """把多个已配音的分镜片段首尾拼接成完整视频"""
    concat_list_path = final_output_path.parent / "concat_list.txt"
    concat_list_path.write_text(
        "\n".join(f"file '{Path(p).resolve()}'" for p in clip_paths),
        encoding="utf-8",
    )
    cmd = [
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", str(concat_list_path),
        "-c", "copy",
        str(final_output_path),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return str(final_output_path)
