"""
第五阶段：视频生成（图生视频）

⚠️ 可灵(Kling) API 需要 access_key/secret_key 生成JWT做鉴权，且是异步任务
（提交任务 -> 轮询任务状态 -> 下载视频），具体字段请对照官方最新文档：
https://klingai.kuaishou.com/ 开放平台文档

这里先给出流程骨架，鉴权和请求体细节需要你申请key后对照文档补全。
"""
import time
import httpx
import config
from pathlib import Path


def generate_video(image_path: str, prompt: str, duration_sec: int, save_path: Path) -> str:
    task_id = _submit_kling_task(image_path, prompt, duration_sec)
    video_bytes = _poll_and_download(task_id)
    save_path.write_bytes(video_bytes)
    return str(save_path)


def _submit_kling_task(image_path: str, prompt: str, duration_sec: int) -> str:
    # TODO: 补充 JWT 鉴权头生成逻辑（可灵官方SDK/文档有示例）
    # TODO: 补充图生视频任务提交接口的具体endpoint和请求体
    raise NotImplementedError("请对照可灵开放平台文档补充：JWT鉴权 + 提交图生视频任务")


def _poll_and_download(task_id: str) -> bytes:
    # TODO: 轮询任务状态直到成功，再下载视频文件
    # 建议：每隔5-10秒查一次，最多等待5分钟左右超时
    raise NotImplementedError("请对照可灵开放平台文档补充：轮询任务状态 + 下载视频")


def image_to_video_fallback(image_path: str, duration_sec: int, save_path: Path) -> str:
    """
    降级方案：如果没有申请到视频生成API，或者想先跑通整条流水线，
    可以用FFmpeg把静态图片做成带缓慢缩放（Ken Burns效果）的视频片段。
    """
    import subprocess
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", str(image_path),
        "-vf", f"zoompan=z='min(zoom+0.0015,1.2)':d={duration_sec*25}:s=1080x1920",
        "-t", str(duration_sec), "-r", "25", "-pix_fmt", "yuv420p",
        str(save_path),
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return str(save_path)
