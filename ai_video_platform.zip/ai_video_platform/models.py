from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base


class Project(Base):
    """一个视频生成任务"""
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    topic = Column(String, nullable=False)          # 用户输入的主题/需求
    script = Column(Text, default="")                 # 生成的完整剧本
    status = Column(String, default="created")
    # created -> script_done -> storyboard_done -> assets_done
    # -> images_done -> audio_done -> video_done -> composed -> failed
    error_message = Column(Text, default="")
    output_path = Column(String, default="")          # 最终成片路径
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    scenes = relationship("Scene", back_populates="project", cascade="all, delete-orphan")


class Scene(Base):
    """单个分镜"""
    __tablename__ = "scenes"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"))
    order = Column(Integer, nullable=False)            # 分镜顺序
    description = Column(Text, default="")             # 画面描述 (用于生图/生视频prompt)
    dialogue = Column(Text, default="")                 # 台词/旁白
    duration_sec = Column(Integer, default=5)
    image_path = Column(String, default="")
    video_path = Column(String, default="")
    audio_path = Column(String, default="")

    project = relationship("Project", back_populates="scenes")


class Asset(Base):
    """资产清单条目：角色/场景/道具，用于保持跨镜头一致性"""
    __tablename__ = "assets"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"))
    name = Column(String, nullable=False)               # 例如："女主角-小美"
    asset_type = Column(String, default="character")    # character | scene | prop
    reference_prompt = Column(Text, default="")          # 用于生成定妆照的prompt
    reference_image_path = Column(String, default="")    # 定妆照路径，后续图生图用
