"""统一配置：从 .env 读取各家API key和路径"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = Path(os.getenv("STORAGE_DIR", BASE_DIR / "storage"))
STORAGE_DIR.mkdir(parents=True, exist_ok=True)

# 剧本/分镜 LLM
QWEN_API_KEY = os.getenv("QWEN_API_KEY", "")
QWEN_BASE_URL = os.getenv("QWEN_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")

# 图片生成
IMAGE_API_KEY = os.getenv("IMAGE_API_KEY", "")
IMAGE_PROVIDER = os.getenv("IMAGE_PROVIDER", "wanxiang")

# 视频生成 - 可灵
KLING_ACCESS_KEY = os.getenv("KLING_ACCESS_KEY", "")
KLING_SECRET_KEY = os.getenv("KLING_SECRET_KEY", "")

# 配音
TTS_API_KEY = os.getenv("TTS_API_KEY", "")
TTS_PROVIDER = os.getenv("TTS_PROVIDER", "aliyun")

# SQLite 数据库文件
DATABASE_URL = f"sqlite:///{BASE_DIR / 'app.db'}"


def project_dir(project_id: int) -> Path:
    """每个项目一个独立文件夹，存放该项目的所有中间产物"""
    d = STORAGE_DIR / f"project_{project_id}"
    for sub in ("images", "videos", "audio", "output"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    return d
